describe('game', () => {
  it('should have a passing test', () => {
    expect(true).toBe(true);
  });
});
